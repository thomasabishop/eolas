declare module "markdown-link-extractor"
